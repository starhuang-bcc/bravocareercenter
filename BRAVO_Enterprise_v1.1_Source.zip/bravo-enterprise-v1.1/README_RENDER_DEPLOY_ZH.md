# BRAVO 人才管理 v1.1：部署說明

這是已整合 render-v1.0-migration 分支的人才管理原始碼，包含企業登入、招募需求、JD、出勤月表／打卡、Excel 匯入、人才簽名及費用試算。

## 上傳方式
Render 的 Git-backed Static Site／Web Service 以 GitHub 儲存庫為來源，不直接接收 ZIP 原始碼。
1. 解壓縮，進入 bravo-enterprise-v1.1 資料夾。
2. 將資料夾內的檔案更新到 GitHub starhuang-bcc/bravocareercenter 的 render-v1.0-migration 分支根目錄；不要把 bravo-enterprise-v1.1 外層資料夾當成新的根目錄。
3. 完整保留 pnpm-lock.yaml，且不要上傳 .env、密碼或資料庫網址。
4. 更適合已有 GitHub 專案的方式：合併 PR #1 到 render-v1.0-migration，毋須重新上傳 ZIP。
   https://github.com/starhuang-bcc/bravocareercenter/pull/1

## A. API Web Service：先部署
原本 API：bravo-career-center-api-sbzq.onrender.com。
- 使用同一個儲存庫、render-v1.0-migration 分支。
- Build：corepack pnpm install --frozen-lockfile && corepack pnpm build
- Start：corepack pnpm start
- Health Check：/health
- 保留原 DATABASE_URL、ADMIN_PASSWORD、SMTP_PASS、JWT_SECRET 等環境變數。
- 新增 ENTERPRISE_ADMIN_EMAIL：你的 BRAVO 管理員 Email。
- 新增 ENTERPRISE_ADMIN_PASSWORD：至少 12 字元的初始密碼，僅在 Render 環境變數設定。
- ENTERPRISE_ORIGIN：https://bravocareercenter.com,https://www.bravocareercenter.com
- CORS_ORIGINS 保留現有設定，若使用測試 Static Site 的 onrender.com 網址，也將該完整 origin 加入。
- 使用既有 MySQL，首次企業平台請求會建立兩張 bravo_enterprise_* 表，需要 CREATE TABLE 權限；不改既有表。
- 按 Manual Deploy → Deploy latest commit，確認 /health 正常。

## B. 官網 Static Site：再部署
Service ID：srv-daokj9bbc2fs73ed8d5g。
- 分支：render-v1.0-migration。
- Build：corepack pnpm install --frozen-lockfile && corepack pnpm vite build
- Publish Directory：dist/public
- VITE_API_BASE_URL：https://bravo-career-center-api-sbzq.onrender.com（若 API 網址不同，以實際 API 為準）
- 保留既有 /* → /index.html 的 Rewrite，才能直接開啟 /enterprise/login。
- 按 Manual Deploy → Deploy latest commit。

## C. 驗收
1. 官網「人才管理｜企業登入」入口可開啟。
2. 用 API 環境變數指定的管理員登入，建立廠商、人才及各自帳號。
3. 產生月表，核對假日與留停排除日期；預設 09:00–18:00。
4. 人才登入確認簽名，再由 BRAVO 發布，廠商登入後只能看到自己的人才。
5. 確認重新整理後資料仍存在，修改出勤後舊簽名失效。

## 已完成與仍需核對
- 型別檢查、建置、16 項新功能測試通過。
- 尚未在正式 MySQL 與瀏覽器畫面完成驗證。
- LINE Login／LIFF 尚未串接，目前是官網每日打卡。
- 特殊假勤、年度額度、假日加班需 BRAVO 核定，不是全自動法規判斷。
- 費用未稅：月薪 + 12% 保險費 + 10% 管理費。請款加減基準預設待合約確認。
- 若瀏覽器封鎖跨站 Cookie，建議 API 綁定 api.bravocareercenter.com，並同步更新 VITE_API_BASE_URL 與允許來源；不可改用公開資料或 localStorage 冒充已登入。
- 詳細設定與限制：notes/enterprise-platform.md。
